const playSound = () => {
    const audio = new Audio('563311__davince21__harp-motif2.ogg');
    audio.play();
};